print('Contact:',
      'Tg:teddy_ga')
print('__________________________________')
import random
import time

def print_with_delay(text, delay=0.005):
    for char in text:
        print(char, end='', flush=True)
        time.sleep(delay)
    print()

def input_with_delay(prompt, delay=0.005):
    for char in prompt:
        print(char, end='', flush=True)
        time.sleep(delay)
    return input()

def select_players():
    print_with_delay("Введите количество игроков (1-4): ")
    while True:
        try:
            num_players = int(input_with_delay("", 0.005))
            if 1 <= num_players <= 4:
                return num_players
            else:
                print_with_delay("Пожалуйста, введите число от 1 до 4.")
        except ValueError:
            print_with_delay("Неверный ввод. Пожалуйста, введите допустимое число.")

def select_items_count():
    print_with_delay("Введите количество предметов на каждого игрока (1-3): ")
    while True:
        try:
            num_items = int(input_with_delay("", 0.005))
            if 1 <= num_items <= 3:
                return num_items
            else:
                print_with_delay("Пожалуйста, введите число от 1 до 3.")
        except ValueError:
            print_with_delay("Неверный ввод. Пожалуйста, введите допустимое число.")

def select_items(num_items):
    items = ["Радиоприёмник", "Блокнот", "Фотокамера", "Видеокамера", "Штатив", "Детектор ЭМП", "Фонарик",
             "Ультрафиолетовый фонарик", "Лазерный проектор", "Термометр", "Распятие", "Свеча", "Благовония",
             "Зажигалка и спичечный коробок", "Неоновая палочка", "Камера с креплением на голове", "Датчик движения",
             "Датчик звука", "Направленный микрофон", "Соль", "Успокоительное"]
    return random.sample(items, num_items)

def select_map():
    maps = [
        "6 Tanglewood Drive",
        "10 Ridgeview Court",
        "13 Willow Street",
        "42 Edgefield Road",
        "Bleasdale Farmhouse",
        "Camp Woodwind",
        "Grafton Farmhouse",
        "Sunny Meadows Mental Institution (Restricted)",
        "Maple Lodge Campsite",
        "Prison",
        "Brownstone High School",
        "Sunny Meadows Mental Institution"
    ]
    return random.choice(maps)

def select_cursed_items():
    return random.randint(0, 3)

def select_cursed_items_list(num_cursed_items):
    cursed_items = ["Доска Уиджи", "Музыкальная шкатулка", "Кукла вуду", "Круг призыва", "Зачарованное зеркало",
                    "Карты Таро", "Обезьянья лапа"]
    return random.sample(cursed_items, num_cursed_items)

def select_settings():
    num_cursed_items = select_cursed_items()

    settings = {
        'Игрок': {
            'Начальный рассудок': random.choice([0, 25, 75, 100]),
            'Эффективность успокоительного': random.choice([0, 5, 10, 20, 25, 30, 35, 40, 45, 50, 75, 100]),
            'Скорость снижения рассудка': random.choice([0, 50, 100]),
            'Бег': random.choice(['выкл', 'вкл', 'Бесконечно']),
            'Скорость игрока в %': random.choice([50, 75, 100]),
            'Фонарики': random.choice(['вкл', 'выкл']),
            'Потеря предметов': random.choice(['вкл', 'выкл'])
        },
        'Призрак': {
            'Скорость призрака в %': random.choice([50, 75, 100]),
            'Частота перемещений': random.choice(['низко', 'средне', 'высоко']),
            'Смена любимой комнаты': random.choice(['нет', 'низко', 'средне', 'высоко']),
            'Количество взаимодействий': random.choice(['низко', 'средне', 'высоко']),
            'Частота событий': random.choice(['низко', 'средне', 'высоко']),
            'Дружелюбное приведение': random.choice(['выкл', 'вкл']),
            'Безопасный период (в секундах)': random.randint(0, 5),
            'Длительность охоты': random.choice(['низко', 'средне', 'высоко']),
            'Сколько времени добавляется к длительности каждой охоты, при смерти': random.choice(['выкл', 'низко', 'средне', 'высоко']),
            'Количество доказательств': random.randint(0, 3),
            'Шанс призрака оставить отпечатки (в процентах)': random.choice([25, 75, 100]),
            'Как долго держаться отпечатки': random.choice([15, 30, 60, 120, 180, 'Бесконечно'])
        },
        'Контракт': {
            'Время на расстановку предметов (в секундах)': random.choice([0, 30, 60, 120, 180, 240, 300]),
            'Погода': random.choice(['Дождь', 'ливень', 'снегопад', 'ветер', 'ясно', 'туман', 'рассвет']),
            'Двери открыты по умолчанию': random.choice(['нет', 'низко', 'средне', 'высоко']),
            'Количество укрытий': random.choice(['нет', 'низко', 'средне', 'высоко', 'очень высоко']),
            'Монитор рассудка': random.choice(['вкл', 'выкл']),
            'Монитор активности': random.choice(['вкл', 'выкл']),
            'Электрический щиток доступен уже в начале игры': random.choice(['вкл', 'выкл', 'сломан']),
            'Электрический щиток видно на карте': random.choice(['вкл', 'выкл']),
            'Количество проклятых предметов': num_cursed_items
        }
    }

    if num_cursed_items > 0:
        cursed_item_selection = select_cursed_items_list(num_cursed_items)
        settings['Контракт']['Выбор проклятого предмета'] = cursed_item_selection

    return settings

def select_task():
    tasks = [
        "Каждый игрок может носить одновременно только один предмет (исключение: Фонарик)."
        "Вам нельзя завершить игру, если вы не сделали фотографию грязной воды."
        "Найдите комнату призрака используя для этого только направленный микрофон."
        "Почувствуйте себя коллекционером: прежде чем закрыть фургон, похвастайтесь 3 трофеями, которые вы забрали из дома. Если предметы игроков повторяются, вам надо найти другие."
        "Заставьте призрака начать охоту с самого начала игры, используя проклятый предмет."
        "Единственный источник света, который вам разрешено использовать - свеча и ультрафиолетовый фонарь."
        "Вам запрещено использовать предметы отпугивающие призрака (распятие, благовоние)."
        "Найдите комнату призрака используя для этого только свечу."
        "Нельзя использовать видеокамеры (даже если выпало в предметах). Для подтверждения призрачного огонька используйте камеру с креплением на голову."
        "Нельзя использовать предметы для поиска улик, определите тип призрака только по его поведению."
        "Если вы зашли на локацию, то уже не можете выйти из неё обратно к фургону. Возьмите все сгенерированые предметы с собой заранее."
        "Игроки не могут вслух произосить найденные улики или предметы на локации."
        "Остановите охоту распятием, держа его в руке."
        "В комнате может находиться лишь один человек, заходить в коридор следует тоже по очереди."
        "Найдите комнату призрака используя для этого только датчики движения."
        "Вам нужно проявить всё своё творчество для фотографии призрака. Создайте в его комнате романтический уют и сфотографируйте призрака на этом фоне."
        "Используйте только предметы 1-го тира."
        "Примените стратегии выживания, чтобы избежать нападения призрака."
    ]

    print_with_delay("Хотите добавить дополнительное задание? (y/n): ")
    user_input = input_with_delay("", 0.005).lower()

    if user_input == 'y':
        return random.choice(tasks)
    else:
        return None

def start_game_with_animation_and_tasks():
    task = select_task()
    if task:
        print_with_delay(f"\nВаше дополнительное задание: {task}")

    print_with_delay("Добро пожаловать в игру!")
    num_players = select_players()
    selected_map = select_map()

    print_with_delay(f"\nВыбранная карта: {selected_map}")
    print_with_delay(f"Количество игроков: {num_players}")

    num_items = select_items_count()

    for player in range(num_players):
        player_items = select_items(num_items)
        print_with_delay(f"\nИгрок {player + 1}, вот ваши предметы: {', '.join(player_items)}")

    game_settings = select_settings()
    print_with_delay("\nНастройки игры:")
    for category, values in game_settings.items():
        print_with_delay(f"{category.capitalize()}:")
        for key, value in values.items():
            print_with_delay(f"  {key.capitalize()}: {value}")

# Запустить игру с анимацией и дополнительными заданиями
start_game_with_animation_and_tasks()
input("Press Enter to exit")

